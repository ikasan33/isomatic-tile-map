using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine;
using UnityEngine.SceneManagement;
public class chageScene : MonoBehaviour
{
    public void GameScenesCtrl()
    {
        SceneManager.LoadScene(1);
    }
}
